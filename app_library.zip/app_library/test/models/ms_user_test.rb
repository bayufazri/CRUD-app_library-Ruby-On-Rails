require 'test_helper'

class MsUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
