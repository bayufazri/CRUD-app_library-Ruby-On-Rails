require 'test_helper'

class TrLoanTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
