require 'test_helper'

class MsMemberTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
