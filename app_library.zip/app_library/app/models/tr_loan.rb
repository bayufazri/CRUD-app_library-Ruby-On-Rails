class TrLoan < ApplicationRecord
end
