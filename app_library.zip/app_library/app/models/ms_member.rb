class MsMember < ApplicationRecord
end
