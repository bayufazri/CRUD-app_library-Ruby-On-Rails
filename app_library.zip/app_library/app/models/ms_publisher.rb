class MsPublisher < ApplicationRecord
end
