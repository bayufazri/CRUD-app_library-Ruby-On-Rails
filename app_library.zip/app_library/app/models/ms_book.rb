class MsBook < ApplicationRecord
end
