module MsBooksHelper
end
