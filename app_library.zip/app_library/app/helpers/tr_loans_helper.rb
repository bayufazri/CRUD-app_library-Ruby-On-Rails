module TrLoansHelper
end
